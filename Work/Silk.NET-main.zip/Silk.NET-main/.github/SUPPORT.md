# Getting Support
For support, please either use [GitHub Discussions](https://github.com/dotnet/Silk.NET/discussions) or chat to us on [Discord](https://discord.com/invite/DTHHXRt).


<a href="https://discord.com/invite/DTHHXRt"><img src="https://img.shields.io/badge/chat%20on-discord-7289DA" alt="Banner image of the Silk.NET Discord server"/></a>


Please do not use issues for support, issues are for bug reports only.
