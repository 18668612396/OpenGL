---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''

---
# Summary of feature
A clear and concise description of what you want to happen.

# Comments

# Does this have a proposal?
Check the documentation/proposals folder. If it doesn't have one, you may need to create one if you're making **massive breaking changes**.
