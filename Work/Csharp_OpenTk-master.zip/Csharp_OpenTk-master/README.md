#Csharp_OpenTk

注意：解压bin/debug.rar可得到资源文件
程序运行后F1-F2可进入编辑模式

观察操作wsad移动，鼠标左键拖动观察视角