﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace testopenTk
{
    static class Program
    {
        public static Form1 Myform ;
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Myform = new Form1();
            Application.Run(Myform);
        }
    }
}
