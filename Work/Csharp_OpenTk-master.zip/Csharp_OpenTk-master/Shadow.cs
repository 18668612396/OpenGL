﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OpenTK.Graphics.OpenGL;
namespace testopenTk
{
    /// <summary>
    /// 阴影，未完成
    /// </summary>
    public static class Shadow
    {
        public static int FBO = -1;
        public static int m_shadowMap;
        public static bool initShadow(int WindowWidth, int WindowHeight)
        {
            FBO = GL.GenFramebuffer();
            m_shadowMap= GL.GenTexture();
            GL.BindTexture(TextureTarget.Texture2D, m_shadowMap);
            GL.TexImage2D(TextureTarget.Texture2D, 0,PixelInternalFormat.DepthComponent,
                WindowWidth, WindowHeight, 0,PixelFormat.DepthComponent,PixelType.Float, IntPtr.Zero);
            GL.TexParameter(TextureTarget.Texture2D,TextureParameterName.TextureMinFilter,(float)TextureMinFilter.Linear);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter,(float)TextureMagFilter.Linear);
            GL.TexParameter(TextureTarget.Texture2D,TextureParameterName.TextureWrapS,(float)All.Clamp);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapT,(float)All.Clamp );
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, FBO);
            GL.FramebufferTexture2D(FramebufferTarget.Framebuffer,FramebufferAttachment.DepthAttachment
                ,TextureTarget.Texture2D, m_shadowMap, 0);
            GL.DrawBuffer(DrawBufferMode.None);
            GL.ReadBuffer(ReadBufferMode.None);
            if (GL.CheckFramebufferStatus(FramebufferTarget.Framebuffer)== FramebufferErrorCode.FramebufferComplete)
            {
                return true;
            }
            //MyMessage.show(GL.CheckFramebufferStatus(FramebufferTarget.Framebuffer).ToString());
            return false;
        }
        public static void bindforwirting()
        {
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, FBO);
        }
        public static void BindForReading(TextureUnit t)
        {
            GL.ActiveTexture(t);
            GL.BindTexture(TextureTarget.Texture2D, m_shadowMap);
        }
    }
}
