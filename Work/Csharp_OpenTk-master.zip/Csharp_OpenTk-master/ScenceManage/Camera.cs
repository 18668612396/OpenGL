﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using System.Drawing;

namespace testopenTk
{
    public static class Camera
    {
        static Matrix4 perspective;
        public static void SetCamera(int w, int h)
        {
            perspective = Matrix4.CreatePerspectiveFieldOfView(MathHelper.PiOver6, w / (float)h, 0.1f, 128);
            //perspective = Matrix4.CreateTranslation(location) * perspective;
            if (Shader.Projection != 0)
                GL.UniformMatrix4(Shader.Projection, false, ref perspective);
        }
        public static bool Left = false, Right = false, Up = false,
            Down = false,Y_Up=false,Y_Down=false;
        static int speed = 1;
        public static Matrix4 MainCamera = Matrix4.Identity;
        public static Matrix4 Location = Matrix4.Identity;
        static Vector4 area=new Vector4(8,-8,6,-6);
        public static Matrix4 LastCamera = Matrix4.Identity;
        public static Matrix4 Rota_Y = Matrix4.Identity;
        public static bool collision = false;
        public static void UpdateCamera(float ms)
        {
            LastCamera = Location;
            ms = ms / 1000;
            speed = (int)Program.Myform.num_speed.Value;

            #region caozuo
            if (!collision&&Location.M42>-10)
            {
                Location = Matrix4.CreateTranslation(0, -3 * speed * ms, 0) * Location;
                MainCamera = MainCamera * Matrix4.CreateTranslation(0, 3 * speed * ms / 100, 0);
                if (Location.M42<-10)
                {
                    Location.M42 = -10;
                    MainCamera = Location.Inverted();
                }
            }
           
            if (Y_Up)
            {
                Location = Matrix4.CreateTranslation(0, 50*speed * ms, 0) * Location;
                MainCamera = MainCamera * Matrix4.CreateTranslation(0, -50*speed * ms, 0);
            }
            if (Y_Down)
            {
                Location = Matrix4.CreateTranslation(0, -speed * ms, 0) * Location;
                MainCamera = MainCamera * Matrix4.CreateTranslation(0, speed * ms, 0);
            }
            if (Up)
            {
                Location = Matrix4.CreateTranslation(0, 0, -speed * ms) * Location;
                MainCamera = MainCamera * Matrix4.CreateTranslation(0, 0, speed * ms);
               
            }
            if (Down)
            {
                Location = Matrix4.CreateTranslation(0, 0, speed * ms) * Location;
                MainCamera = MainCamera * Matrix4.CreateTranslation(0, 0, -speed * ms);
                
            }
            if (Left)
            {
                Location = Matrix4.CreateRotationY(1 * ms) * Location;
                MainCamera = MainCamera * Matrix4.CreateRotationY(-1 * ms);
            }
            if (Right)
            {
                Location = Matrix4.CreateRotationY(-1 * ms) * Location;
                MainCamera = MainCamera * Matrix4.CreateRotationY(1 * ms);
            }
            MyMessage.lable4Show("摄像机矩阵：" + Environment.NewLine
                + MainCamera.ToString() + Environment.NewLine
                + Environment.NewLine
                + Location.ToString() + Environment.NewLine
                + "摄像机位置：" + Location.M41.ToString() + ","
                + Location.M42.ToString() + "," + Location.M43.ToString()
                 );
            #endregion
            
        }

        public static void SetCameraLocation(float x,float y, float z)
        {
            Location.M41 = x;
            Location.M42 = y;
            Location.M43 = z;
            MainCamera = Location.Inverted();
        }
    }

}
