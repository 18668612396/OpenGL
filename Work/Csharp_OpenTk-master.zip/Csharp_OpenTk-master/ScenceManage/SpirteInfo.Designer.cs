﻿namespace testopenTk
{
    partial class SpirteInfo
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.Location_X = new System.Windows.Forms.NumericUpDown();
            this.Location_Y = new System.Windows.Forms.NumericUpDown();
            this.Location_Z = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Rotate_X = new System.Windows.Forms.NumericUpDown();
            this.Rotate_Y = new System.Windows.Forms.NumericUpDown();
            this.Rotate_Z = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.num_Animation = new System.Windows.Forms.NumericUpDown();
            this.num_layer = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Location_X)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Location_Y)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Location_Z)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Rotate_X)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Rotate_Y)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Rotate_Z)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Animation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_layer)).BeginInit();
            this.SuspendLayout();
            // 
            // Location_X
            // 
            this.Location_X.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.Location_X.DecimalPlaces = 1;
            this.Location_X.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.Location_X.Location = new System.Drawing.Point(24, 60);
            this.Location_X.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.Location_X.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.Location_X.Name = "Location_X";
            this.Location_X.Size = new System.Drawing.Size(68, 21);
            this.Location_X.TabIndex = 0;
            // 
            // Location_Y
            // 
            this.Location_Y.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.Location_Y.DecimalPlaces = 1;
            this.Location_Y.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.Location_Y.Location = new System.Drawing.Point(24, 87);
            this.Location_Y.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.Location_Y.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.Location_Y.Name = "Location_Y";
            this.Location_Y.Size = new System.Drawing.Size(68, 21);
            this.Location_Y.TabIndex = 0;
            // 
            // Location_Z
            // 
            this.Location_Z.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.Location_Z.DecimalPlaces = 1;
            this.Location_Z.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.Location_Z.Location = new System.Drawing.Point(24, 114);
            this.Location_Z.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.Location_Z.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.Location_Z.Name = "Location_Z";
            this.Location_Z.Size = new System.Drawing.Size(68, 21);
            this.Location_Z.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "位置:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 160);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 12);
            this.label3.TabIndex = 1;
            this.label3.Text = "旋转:";
            // 
            // Rotate_X
            // 
            this.Rotate_X.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.Rotate_X.DecimalPlaces = 1;
            this.Rotate_X.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.Rotate_X.Location = new System.Drawing.Point(24, 185);
            this.Rotate_X.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.Rotate_X.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.Rotate_X.Name = "Rotate_X";
            this.Rotate_X.Size = new System.Drawing.Size(68, 21);
            this.Rotate_X.TabIndex = 0;
            // 
            // Rotate_Y
            // 
            this.Rotate_Y.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.Rotate_Y.DecimalPlaces = 1;
            this.Rotate_Y.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.Rotate_Y.Location = new System.Drawing.Point(24, 212);
            this.Rotate_Y.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.Rotate_Y.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.Rotate_Y.Name = "Rotate_Y";
            this.Rotate_Y.Size = new System.Drawing.Size(68, 21);
            this.Rotate_Y.TabIndex = 0;
            // 
            // Rotate_Z
            // 
            this.Rotate_Z.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.Rotate_Z.DecimalPlaces = 1;
            this.Rotate_Z.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.Rotate_Z.Location = new System.Drawing.Point(24, 239);
            this.Rotate_Z.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.Rotate_Z.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.Rotate_Z.Name = "Rotate_Z";
            this.Rotate_Z.Size = new System.Drawing.Size(68, 21);
            this.Rotate_Z.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(123, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 12);
            this.label4.TabIndex = 2;
            this.label4.Text = "动作索引:";
            // 
            // num_Animation
            // 
            this.num_Animation.Location = new System.Drawing.Point(119, 81);
            this.num_Animation.Name = "num_Animation";
            this.num_Animation.Size = new System.Drawing.Size(68, 21);
            this.num_Animation.TabIndex = 3;
            // 
            // num_layer
            // 
            this.num_layer.Location = new System.Drawing.Point(119, 133);
            this.num_layer.Name = "num_layer";
            this.num_layer.Size = new System.Drawing.Size(68, 21);
            this.num_layer.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(123, 112);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 12);
            this.label5.TabIndex = 4;
            this.label5.Text = "所属层:";
            // 
            // SpirteInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.num_layer);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.num_Animation);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Rotate_Z);
            this.Controls.Add(this.Location_Z);
            this.Controls.Add(this.Rotate_Y);
            this.Controls.Add(this.Location_Y);
            this.Controls.Add(this.Rotate_X);
            this.Controls.Add(this.Location_X);
            this.Name = "SpirteInfo";
            this.Size = new System.Drawing.Size(270, 424);
            this.Load += new System.EventHandler(this.SpirteInfo_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.SpirteInfo_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.SpirteInfo_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.SpirteInfo_MouseUp);
            ((System.ComponentModel.ISupportInitialize)(this.Location_X)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Location_Y)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Location_Z)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Rotate_X)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Rotate_Y)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Rotate_Z)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Animation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_layer)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.NumericUpDown Location_X;
        public System.Windows.Forms.NumericUpDown Location_Z;
        public System.Windows.Forms.NumericUpDown Location_Y;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.NumericUpDown Rotate_X;
        public System.Windows.Forms.NumericUpDown Rotate_Y;
        public System.Windows.Forms.NumericUpDown Rotate_Z;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.NumericUpDown num_Animation;
        public System.Windows.Forms.NumericUpDown num_layer;
        private System.Windows.Forms.Label label5;
    }
}
