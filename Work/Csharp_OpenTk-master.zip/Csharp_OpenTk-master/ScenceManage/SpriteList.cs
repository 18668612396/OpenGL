﻿using OpenTK.Graphics.OpenGL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK;

namespace testopenTk
{
    public static class SpriteList
    {
        /// <summary>
        /// 绘制的模型列表
        /// </summary>
        public static List<Sprite3D> sprite3Dlist = new List<Sprite3D>();
        /// <summary>
        /// 绘制列表内所有模型
        /// </summary>
        /// <param name="select"></param>

        internal static void Draw(bool select, double timeslice, Matrix4 mainCamera,decimal layer)
        {
            for (int i = 0; i < sprite3Dlist.Count; i++)
            {
                sprite3Dlist[i].Draw(select, timeslice, mainCamera,layer);
            }
        }
        public static void DisposeResoure()
        {
            foreach (Sprite3D t in sprite3Dlist)
            {
                t.DisposeResoure();
            }
            foreach (AssLoad t in MyInfo.alList)
            {
                t.DisposeResoure();
            }
            MyInfo.alList.Clear();
            sprite3Dlist.Clear();
        }
        public static Sprite3D Touch(int nameIndex)
        {
            foreach (Sprite3D t in sprite3Dlist)
            {
                if (t.nameIndex==nameIndex)
                {
                    return t;
                }
            }
            return null;
        }
        /// <summary>
        /// 旧代码，暂时不用
        /// </summary>
        /// <param name="str"></param>
        static void AddNew(string[] str)
        {
            foreach (string t in str)
            {
                sprite3Dlist.Add(new Sprite3D(t));
            }
        }
        public static void DeleteAll()
        {
            DisposeResoure();
        }
        public static void DeleteTouch()
        {
            Sprite3D temp3d=null;
            foreach (Sprite3D t in sprite3Dlist)
            {
                if (t.touch==true)
                {
                    temp3d = t;
                }
            }
            if (temp3d!=null)
            {
                bool isElse = false;
                foreach (Sprite3D t in sprite3Dlist)
                {
                    if (temp3d.spath == t.spath&&temp3d!=t)
                    {
                        isElse = true;
                    }
                }
                sprite3Dlist.Remove(temp3d);
                temp3d.si.Dispose();
                if (!isElse)
                {
                    AssLoad tempAl = null;
                    foreach (AssLoad t in MyInfo.alList)
                    {
                        if (t.filePath == temp3d.spath)
                        {
                            tempAl = t;
                        }
                    }
                    if (tempAl != null)
                    {
                        tempAl.DisposeResoure();
                        MyInfo.alList.Remove(tempAl);
                    }
                    temp3d.DisposeResoure();
                }
            }
           
        }

        public static void CollisionTest()
        {
            for (int i = 0; i < sprite3Dlist.Count; i++)
            {
                if (sprite3Dlist[i]==null)
                {
                    continue;
                }
                sprite3Dlist[i].collision(Camera.Location, Camera.LastCamera);
            }
        }

      
    }
}
