﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace testopenTk
{
    
    public partial class SpirteInfo : UserControl
    {
        private bool click = false;
        private Point mousep;
        public SpirteInfo()
        {
            InitializeComponent();
            
        }

        private void SpirteInfo_Load(object sender, EventArgs e)
        {
            this.Parent.SizeChanged += Parent_SizeChanged;
            //this.Dock = DockStyle.Right;
            //this.Parent.siz
            Location = new Point(Parent.Width - Width, Parent.Height - Height);
        }

        private void Parent_SizeChanged(object sender, EventArgs e)
        {
            if (Parent!=null)
            {
                Location = new Point(Parent.Width - Width, Parent.Height - Height);
            }
            
        }

        //拖动效果
        private void SpirteInfo_MouseDown(object sender, MouseEventArgs e)
        {
           
            if (e.Button == MouseButtons.Left)
            {
                mousep = e.Location;
                click = true;
            }
        }

        private void SpirteInfo_MouseUp(object sender, MouseEventArgs e)
        {
            
            if (e.Button == MouseButtons.Left)
            {
                click = false;
            }
        }
        
        private void SpirteInfo_MouseMove(object sender, MouseEventArgs e)
        {
            
            if (click==true)
            {
                //this.BringToFront();
                this.Top = this.Top + (e.Y - mousep.Y);
                this.Left = this.Left + (e.X - mousep.X);
            }
        }
        /// <summary>
        /// 为属性面板设置名字
        /// </summary>
        /// <param name="s"></param>
        public void SetName( string s)
        {
            this.label1.Text = s;
        }
    }
}
