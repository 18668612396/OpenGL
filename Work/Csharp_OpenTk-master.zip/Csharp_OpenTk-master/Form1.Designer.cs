﻿using OpenTK.Graphics;
using OpenTK;
namespace testopenTk
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码
        GraphicsMode gm = new GraphicsMode(new ColorFormat(32), 8, 8, 8);
        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.glControl1 = new OpenTK.GLControl(gm);
            this.lab_FPS = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.ReadAll = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SaveAll = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.num_speed = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.openFileDialog2 = new System.Windows.Forms.OpenFileDialog();
            this.btn_Aload = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btn_ARead = new System.Windows.Forms.Button();
            this.btn_ASave = new System.Windows.Forms.Button();
            this.lab_info = new System.Windows.Forms.Label();
            this.button_down = new System.Windows.Forms.Panel();
            this.button_up = new System.Windows.Forms.Panel();
            this.button_right = new System.Windows.Forms.Panel();
            this.button_left = new System.Windows.Forms.Panel();
            this.num_layer = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.num_speed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_layer)).BeginInit();
            this.SuspendLayout();
            // 
            // glControl1
            // 
            this.glControl1.BackColor = System.Drawing.Color.Black;
            this.glControl1.Location = new System.Drawing.Point(1, 1);
            this.glControl1.Name = "glControl1";
            this.glControl1.Size = new System.Drawing.Size(473, 283);
            this.glControl1.TabIndex = 0;
            this.glControl1.VSync = false;
            this.glControl1.Load += new System.EventHandler(this.glControl1_Load);
            this.glControl1.Paint += new System.Windows.Forms.PaintEventHandler(this.glControl1_Paint);
            this.glControl1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.glControl1_KeyDown);
            this.glControl1.KeyUp += new System.Windows.Forms.KeyEventHandler(this.glControl1_KeyUp);
            this.glControl1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.glControl1_MouseDown);
            this.glControl1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.glControl1_MouseMove);
            this.glControl1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.glControl1_MouseUp);
            this.glControl1.Resize += new System.EventHandler(this.glControl1_Resize);
            // 
            // lab_FPS
            // 
            this.lab_FPS.AutoSize = true;
            this.lab_FPS.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.lab_FPS.Location = new System.Drawing.Point(495, 21);
            this.lab_FPS.Name = "lab_FPS";
            this.lab_FPS.Size = new System.Drawing.Size(41, 12);
            this.lab_FPS.TabIndex = 1;
            this.lab_FPS.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label2.Location = new System.Drawing.Point(511, 166);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 3;
            this.label2.Text = "label2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label3.Location = new System.Drawing.Point(511, 206);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 4;
            this.label3.Text = "label3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label4.Location = new System.Drawing.Point(511, 397);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 5;
            this.label4.Text = "label4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label5.Location = new System.Drawing.Point(511, 328);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 12);
            this.label5.TabIndex = 5;
            this.label5.Text = "label5";
            // 
            // ReadAll
            // 
            this.ReadAll.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.ReadAll.Enabled = false;
            this.ReadAll.Location = new System.Drawing.Point(567, 45);
            this.ReadAll.Name = "ReadAll";
            this.ReadAll.Size = new System.Drawing.Size(75, 23);
            this.ReadAll.TabIndex = 6;
            this.ReadAll.Text = "读取";
            this.ReadAll.UseVisualStyleBackColor = true;
            this.ReadAll.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Enabled = false;
            this.button2.Location = new System.Drawing.Point(497, 45);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(64, 23);
            this.button2.TabIndex = 10;
            this.button2.Text = "载入";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // SaveAll
            // 
            this.SaveAll.Enabled = false;
            this.SaveAll.Location = new System.Drawing.Point(567, 16);
            this.SaveAll.Name = "SaveAll";
            this.SaveAll.Size = new System.Drawing.Size(75, 23);
            this.SaveAll.TabIndex = 11;
            this.SaveAll.Text = "保存所有";
            this.SaveAll.UseVisualStyleBackColor = true;
            this.SaveAll.Click += new System.EventHandler(this.SaveAll_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.Filter = "aaa|*.obj";
            this.openFileDialog1.RestoreDirectory = true;
            this.openFileDialog1.Title = "不支持的obj文件将没有反应";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // btn_Delete
            // 
            this.btn_Delete.Location = new System.Drawing.Point(399, 305);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(75, 23);
            this.btn_Delete.TabIndex = 12;
            this.btn_Delete.Text = "删除此模型";
            this.btn_Delete.UseVisualStyleBackColor = true;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // num_speed
            // 
            this.num_speed.Location = new System.Drawing.Point(497, 373);
            this.num_speed.Name = "num_speed";
            this.num_speed.ReadOnly = true;
            this.num_speed.Size = new System.Drawing.Size(86, 21);
            this.num_speed.TabIndex = 14;
            this.num_speed.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(511, 239);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 12);
            this.label6.TabIndex = 15;
            this.label6.Text = "label6";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(12, 334);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(353, 244);
            this.listBox1.TabIndex = 16;
            // 
            // openFileDialog2
            // 
            this.openFileDialog2.Multiselect = true;
            this.openFileDialog2.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog2_FileOk);
            // 
            // btn_Aload
            // 
            this.btn_Aload.Location = new System.Drawing.Point(497, 75);
            this.btn_Aload.Name = "btn_Aload";
            this.btn_Aload.Size = new System.Drawing.Size(75, 23);
            this.btn_Aload.TabIndex = 17;
            this.btn_Aload.Text = "Ass载入";
            this.btn_Aload.UseVisualStyleBackColor = true;
            this.btn_Aload.Click += new System.EventHandler(this.btn_load_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(399, 334);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 18;
            this.button1.Text = "删除所有";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // btn_ARead
            // 
            this.btn_ARead.Location = new System.Drawing.Point(496, 107);
            this.btn_ARead.Name = "btn_ARead";
            this.btn_ARead.Size = new System.Drawing.Size(75, 23);
            this.btn_ARead.TabIndex = 19;
            this.btn_ARead.Text = "Ass读取";
            this.btn_ARead.UseVisualStyleBackColor = true;
            this.btn_ARead.Click += new System.EventHandler(this.btn_ARead_Click);
            // 
            // btn_ASave
            // 
            this.btn_ASave.Location = new System.Drawing.Point(496, 140);
            this.btn_ASave.Name = "btn_ASave";
            this.btn_ASave.Size = new System.Drawing.Size(75, 23);
            this.btn_ASave.TabIndex = 20;
            this.btn_ASave.Text = "Ass保存";
            this.btn_ASave.UseVisualStyleBackColor = true;
            this.btn_ASave.Click += new System.EventHandler(this.btn_ASave_Click);
            // 
            // lab_info
            // 
            this.lab_info.AutoSize = true;
            this.lab_info.BackColor = System.Drawing.Color.Transparent;
            this.lab_info.Location = new System.Drawing.Point(511, 194);
            this.lab_info.Name = "lab_info";
            this.lab_info.Size = new System.Drawing.Size(149, 12);
            this.lab_info.TabIndex = 22;
            this.lab_info.Text = "点击关闭文本提示，F6打开";
            this.lab_info.Visible = false;
            this.lab_info.MouseClick += new System.Windows.Forms.MouseEventHandler(this.lab_info_MouseClick);
            // 
            // button_down
            // 
            this.button_down.BackColor = System.Drawing.Color.Black;
            this.button_down.BackgroundImage = global::testopenTk.Properties.Resources.button_down;
            this.button_down.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_down.Location = new System.Drawing.Point(187, 235);
            this.button_down.Name = "button_down";
            this.button_down.Size = new System.Drawing.Size(93, 49);
            this.button_down.TabIndex = 25;
            this.button_down.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            this.button_down.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel3_MouseDown);
            this.button_down.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel3_MouseUp);
            // 
            // button_up
            // 
            this.button_up.BackColor = System.Drawing.Color.Black;
            this.button_up.BackgroundImage = global::testopenTk.Properties.Resources.button_up;
            this.button_up.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_up.Location = new System.Drawing.Point(187, 1);
            this.button_up.Name = "button_up";
            this.button_up.Size = new System.Drawing.Size(93, 49);
            this.button_up.TabIndex = 25;
            this.button_up.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            this.button_up.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel3_MouseDown);
            this.button_up.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel3_MouseUp);
            // 
            // button_right
            // 
            this.button_right.BackColor = System.Drawing.Color.Black;
            this.button_right.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_right.BackgroundImage")));
            this.button_right.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_right.Location = new System.Drawing.Point(381, 141);
            this.button_right.Name = "button_right";
            this.button_right.Size = new System.Drawing.Size(93, 49);
            this.button_right.TabIndex = 24;
            this.button_right.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            this.button_right.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel3_MouseDown);
            this.button_right.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel3_MouseUp);
            // 
            // button_left
            // 
            this.button_left.BackColor = System.Drawing.Color.Black;
            this.button_left.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_left.BackgroundImage")));
            this.button_left.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_left.Location = new System.Drawing.Point(1, 141);
            this.button_left.Name = "button_left";
            this.button_left.Size = new System.Drawing.Size(93, 49);
            this.button_left.TabIndex = 23;
            this.button_left.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            this.button_left.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel3_MouseDown);
            this.button_left.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel3_MouseUp);
            // 
            // num_layer
            // 
            this.num_layer.Location = new System.Drawing.Point(663, 45);
            this.num_layer.Name = "num_layer";
            this.num_layer.Size = new System.Drawing.Size(65, 21);
            this.num_layer.TabIndex = 26;
            this.num_layer.ValueChanged += new System.EventHandler(this.num_layer_ValueChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(661, 21);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 27;
            this.label7.Text = "当前层：";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1015, 586);
            this.Controls.Add(this.lab_info);
            this.Controls.Add(this.button_down);
            this.Controls.Add(this.button_up);
            this.Controls.Add(this.button_right);
            this.Controls.Add(this.button_left);
            this.Controls.Add(this.glControl1);
            this.Controls.Add(this.btn_ASave);
            this.Controls.Add(this.btn_ARead);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btn_Aload);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.num_speed);
            this.Controls.Add(this.btn_Delete);
            this.Controls.Add(this.SaveAll);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.ReadAll);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.num_layer);
            this.Controls.Add(this.lab_FPS);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.DoubleBuffered = true;
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.num_speed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_layer)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public OpenTK.GLControl glControl1;
        private System.Windows.Forms.Label lab_FPS;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label label3;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button ReadAll;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button SaveAll;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button btn_Delete;
        public System.Windows.Forms.NumericUpDown num_speed;
        public System.Windows.Forms.Label label6;
        public System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.OpenFileDialog openFileDialog2;
        private System.Windows.Forms.Button btn_Aload;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btn_ARead;
        private System.Windows.Forms.Button btn_ASave;
        private System.Windows.Forms.Panel button_left;
        private System.Windows.Forms.Panel button_right;
        private System.Windows.Forms.Panel button_up;
        private System.Windows.Forms.Panel button_down;
        public System.Windows.Forms.Label lab_info;
        private System.Windows.Forms.Label label7;
        public System.Windows.Forms.NumericUpDown num_layer;
    }
}

