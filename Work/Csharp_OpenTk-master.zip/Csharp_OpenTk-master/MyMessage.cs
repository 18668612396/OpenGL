﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using OpenTK.Graphics.OpenGL;
using System.Diagnostics;

namespace testopenTk
{
    /// <summary>
    /// 暂停使用
    /// </summary>
    public static class MyMessage
    {
        public static void show(String s)
        {
            MessageBox.Show(s);
        }
        public static void errorShow()
        {

                ErrorCode ec = GL.GetError();
                show(ec.ToString());
        }
        public static void lableShow(String s)
        {
                 Program.Myform.label5.Text = s;
        }
        public static void lable6Show(String s)
        {
            Program.Myform.label6.Text = s;
        }
        public static void listbox(string s)
        {
            Program.Myform.listBox1.Items.Add(s);
        }
        public static void lableErrorShow()
        {
            ErrorCode ec = GL.GetError();
            Program.Myform.label3.Text = (ec.ToString());
        }
        public static void lable4Show(String s)
        {
            Program.Myform.label4.Text = s;
        }
        public static void lable5Show(String s)
        {
            Program.Myform.label5.Text = s;
        }
        static Stopwatch MyTtime = new Stopwatch();
        public static void TimeStart()
        {
            MyTtime.Start();
        }
        public static double TimeStopAndShow()
        {
            MyTtime.Stop();
            TimeSpan timeSpan = MyTtime.Elapsed; //  获取总时间
            double milliseconds = timeSpan.TotalMilliseconds;  //  毫秒数
            MyTtime.Reset();
            return milliseconds;
        }
        public static void LabInfo(string s)
        {
            Program.Myform.lab_info.Text = s;
            Program.Myform.lab_info.Location = new System.Drawing.Point(Program.Myform.
                glControl1.Width / 2 - Program.Myform.lab_info.Width / 2,
                 Program.Myform.glControl1.Height / 4);
        }
    }
}
