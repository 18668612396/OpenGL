﻿open System

[<EntryPoint>]
let main argv =
    printfn "This tutorial has not been written yet."
    printfn "Have a go at using the C++ version of this tutorial at:"
    printfn "    learnopengl.com"
    printfn "Have fun!"
    0
