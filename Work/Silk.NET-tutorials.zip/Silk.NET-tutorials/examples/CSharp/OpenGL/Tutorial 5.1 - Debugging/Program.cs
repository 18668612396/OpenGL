﻿using System;

namespace Tutorial
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("This tutorial has not been written yet.");
            Console.WriteLine("Have a go at using the C++ version of this tutorial at: ");
            Console.WriteLine("    learnopengl.com");
            Console.WriteLine("Have fun!");
        }
    }
}
