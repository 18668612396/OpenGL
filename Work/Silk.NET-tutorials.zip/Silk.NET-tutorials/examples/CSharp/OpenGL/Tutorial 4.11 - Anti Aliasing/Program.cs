﻿using System;

namespace Tutorial_4._11___Anti_Aliasing
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
