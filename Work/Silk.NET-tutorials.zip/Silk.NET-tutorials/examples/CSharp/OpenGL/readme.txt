Chapter 3 has been excluded until Silk.NET has bound to Assimp.

Credit to Joey de Vries and learnopengl.com contributors for the tutorials.