# Third Parties
## AdvancedDLSupport
Ultz has been generously granted a license exemption for Silk.NET, which makes it so our users don't have to abide by AdvancedDLSupport's LGPL license, as long as these conditions are met:

* Don't reference any AdvancedDLSupport classes, or anything in the AdvancedDLSupport.* namespace.

That's it. If you want a legalese version of this, view the [signed copy](https://github.com/Ultz/Silk.NET/blob/master/documentation/AdvancedDLSupport%20-%20Signed%20License%20Grant.pdf).
