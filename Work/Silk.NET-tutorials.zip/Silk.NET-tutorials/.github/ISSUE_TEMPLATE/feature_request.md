---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''

---

- [ ] I have definitely checked that there are no proposals for this already in the [proposals folder](https://github.com/Ultz/Silk.NET-Docs)

# Summary of feature
A clear and concise description of what you want to happen.

# Comments
