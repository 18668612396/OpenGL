namespace Silk.NET.Vulkan
{
    public unsafe delegate void VoidFunction();
}