namespace Silk.NET.Vulkan
{
    public unsafe delegate void FreeFunction(
        void* pUserData,
        void* pMemory);
}