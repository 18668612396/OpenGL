# Welcome to the Silk.NET lab!

This is where we'll put applications that test Silk.NET, as well as other experimental projects.

You don't really need to worry about what goes on in this folder, but there might be some notices below.

## Notices
Sike there are no notices!

For now at least.