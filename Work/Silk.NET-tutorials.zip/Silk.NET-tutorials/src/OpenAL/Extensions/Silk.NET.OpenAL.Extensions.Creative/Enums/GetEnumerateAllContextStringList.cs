﻿// This file is part of Silk.NET.
// 
// You may modify and distribute Silk.NET under the terms
// of the MIT license. See the LICENSE file for details.

namespace Silk.NET.OpenAL.Extensions.Creative
{
    /// <summary>
    /// Defines available parameters for <see cref="IEnumerateAllContextState.GetStringList" />.
    /// </summary>
    public enum GetEnumerateAllContextStringList
    {
        /// <summary>
        /// Gets the specifier strings for all available devices.
        /// </summary>
        AllDevicesSpecifier = 0x1013
    }
}