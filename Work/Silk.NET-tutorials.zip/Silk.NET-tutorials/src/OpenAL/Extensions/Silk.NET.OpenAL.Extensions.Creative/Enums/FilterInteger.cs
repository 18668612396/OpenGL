﻿// This file is part of Silk.NET.
// 
// You may modify and distribute Silk.NET under the terms
// of the MIT license. See the LICENSE file for details.

namespace Silk.NET.OpenAL.Extensions.Creative
{
    /// <summary>
    /// A list of valid <see cref="int" /> Filter/GetFilter parameters.
    /// </summary>
    public enum FilterInteger
    {
        /// <summary>
        /// Used with the enum EfxFilterType as Parameter to select a filter logic.
        /// </summary>
        FilterType = 0x8001
    }
}