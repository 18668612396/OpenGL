#!/bin/sh

dotnet pack --configuration Release -o build/output_packages
